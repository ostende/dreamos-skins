# -*- coding: utf-8 -*-
#######################################################################
#
# My Flow by King_lotzi
#
# Thankfully inspired by:
# MyMetrix
# Coded by iMaxxx (c) 2013
#
# This plugin is licensed under the Creative Commons
# Attribution-NonCommercial-ShareAlike 3.0 Unported License.
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
# or send a letter to Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
# Alternatively, this plugin may be distributed and executed on hardware which
# is licensed by Dream Multimedia GmbH.
#
# This plugin is NOT free software. It is open source, you are allowed to
# modify it (if you keep the license), but it may not be commercially
# distributed other than under the conditions noted above.
#######################################################################

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.Standby import TryQuitMainloop
from Components.ActionMap import NumberActionMap
from Components.AVSwitch import AVSwitch
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from os import environ, listdir, remove, rename, system, path
from skin import parseColor
from Components.Pixmap import Pixmap
import urllib
import gettext
from enigma import ePicLoad

#######################################################################

class MyFlow(ConfigListScreen, Screen):
	skin = """
		<screen name="My Flow" position="center,center" size="600,740" title="My Flow Setup">
		<eLabel font="Regular;20" foregroundColor="#00ff4A3C" halign="center" position="20,308" size="120,26" text="Cancel"/>
		<eLabel font="Regular;20" foregroundColor="#0056C856" halign="center" position="165,308" size="120,26" text="Save"/>
		<widget name="config" position="5,5" scrollbarMode="showOnDemand" size="590,300"/>
		<widget name="preview" position="5,440" size="590,315" zPosition="1" />
		</screen>"""

#######################################################################

	def __init__(self, session, args = None, picPath = None):
		self.skin_lines = []
		Screen.__init__(self, session)
		self.session = session
		self.datei = "/usr/share/enigma2/My Flow/skin.xml"
		self.dateiTMP = "/usr/share/enigma2/My Flow/skin.xml.tmp"
		self.daten = "/usr/lib/enigma2/python/Plugins/Extensions/My Flow/data/"
		self.picPath = picPath
		self.Scale = AVSwitch().getFramebufferScale()
		self.PicLoad = ePicLoad()
		self["preview"] = Pixmap()
		self.onLayoutFinish.append(self.UpdatePicture)
		self["actions"] = NumberActionMap(["OkCancelActions","DirectionActions", "InputActions", "ColorActions", "MenuActions"], {"left": self.keyLeft, "down": self.keyDown, "up": self.keyUp, "right": self.keyRight, "red": self.exit, "green": self.save, "cancel": self.exit}, -1)

#######################################################################

		coloralt=[]
		coloralt.append(("MyFlow", _("My Flow") ))
		coloralt.append(("DarkFlow", _("Dark Flow") ))
		ColorList = []
		ColorList.append(("#21624d", _("My Flow")))
		ColorList.append(("#d55f00", _("orange")))
		ColorList.append(("#367bf0", _("blau")))
		ColorList.append(("#40c8e0", _("türkis")))
		ColorList.append(("#90051f", _("rot")))
		ColorList.append(("#e8ff22", _("gelb")))
		clockalt=[]
		clockalt.append(("noclock", _("keine Uhr") ))
		clockalt.append(("Flowclock", _("My Flow") ))
		volumealt=[]
		volumealt.append(("FlowVolume", _("My Flow") ))
		volumealt.append(("Volumealternative", _("Volume links") ))
		channelalt=[]
		channelalt.append(("Flowchannel", _("ohne PIG") ))
		channelalt.append(("Flowchannel2", _("with Poster") ))
		channelalt.append(("Flowchannel3", _("with Poster for 5 Event") ))
		channelalt.append(("Flowchannel1", _("ohne PIG, + Kanalinfo") ))
		channelalt.append(("PigChannel", _("mit PIG") ))
		displayalt=[]
		displayalt.append(("Leftpicdisplay", _("My Flow") ))
		displayalt.append(("Toppicdisplay", _("Alternativ") ))
		leftalt=[]
		leftalt.append(("Nothing", _("nichts") ))
		leftalt.append(("ECM", _("ECMinfo") ))
		leftalt.append(("VPNl", _("VPNinfo") ))
		leftalt.append(("CPUtempl", _("CPUtemp") ))
		leftalt.append(("Kanalinfo", _("Kanal+ECMinfo") ))
		rechtsalt=[]
		rechtsalt.append(("Nothing", _("nichts") ))
		rechtsalt.append(("Weather", _("Wetter") ))
		rechtsalt.append(("CPUtempr", _("CPUtemp") ))
		rechtsalt.append(("VPNr", _("VPNinfo") ))
		weatheralt=[]
		weatheralt.append(("Nothing", _("no") ))
		weatheralt.append(("Weathert", _("yes") ))
 		vpnalt=[]
		vpnalt.append(("Nothing", _("no") ))
		vpnalt.append(("VPNo", _("yes") ))
		tuneralt=[]
		tuneralt.append(("Nothing", _("nichts") ))
		tuneralt.append(("2tuner", _("2 Tuner") ))
		tuneralt.append(("3tuner", _("3 Tuner") ))
		tuneralt.append(("4tuner", _("4 Tuner") ))
		tuneralt.append(("5tuner", _("5 Tuner") ))
		tuneralt.append(("Fbctuner", _("FBC Tuner") ))
		tuneralt.append(("Provider", _(" Provider") ))
		messagealt=[]
		messagealt.append(("MMitte", _("Mitte") ))
		messagealt.append(("Mlinks", _("links") ))
		messagealt.append(("Mrechts", _("rechts") ))
		timeshiftalt=[]
		timeshiftalt.append(("TSUntenRechts", _("rechts unten") ))
		timeshiftalt.append(("TSObenMitte", _("oben Mitte") ))
		radioinfoalt=[]
		radioinfoalt.append(("RadioInfoM", _("Standard") ))
		radioinfoalt.append(("RadioInfoLU", _("links unten") ))
		radioinfoalt.append(("RadioInfoRU", _("rechts unten") ))
		radioinfoalt.append(("RadioInfoLO", _("links oben") ))
		radioinfoalt.append(("RadioInfoRO", _("rechts oben") ))
		gp41=[]
		gp41.append(("Nothing", _("no") ))
		gp41.append(("gp41", _("yes") ))
		posteralt=[]
		posteralt.append(("Nothing", _("no") ))
		posteralt.append(("Poster", _("yes") ))


		config.plugins.My_Flow = ConfigSubsection()
		config.plugins.My_Flow.Color = ConfigSelection(default="MyFlow", choices = coloralt)
		config.plugins.My_Flow.SelectionBackground = ConfigSelection(default="#21624d", choices = ColorList)
		config.plugins.My_Flow.Volume = ConfigSelection(default="FlowVolume", choices = volumealt)
		config.plugins.My_Flow.Channel = ConfigSelection(default="PigChannel", choices = channelalt)
		config.plugins.My_Flow.Display = ConfigSelection(default="Leftpicdisplay", choices = displayalt)
		config.plugins.My_Flow.Clock = ConfigSelection(default="Flowclock", choices = clockalt)
		config.plugins.My_Flow.LeftInfoBar = ConfigSelection(default="Nothing", choices = leftalt)
		config.plugins.My_Flow.PosterInfoBar = ConfigSelection(default="Nothing", choices = posteralt)
		config.plugins.My_Flow.WeatherInfoBar = ConfigSelection(default="Nothing", choices = weatheralt)
		config.plugins.My_Flow.RechtsInfoBar = ConfigSelection(default="Nothing", choices = rechtsalt)
		config.plugins.My_Flow.VPNInfoBar = ConfigSelection(default="Nothing", choices = vpnalt)
		config.plugins.My_Flow.TunerInfoBar = ConfigSelection(default="Nothing", choices = tuneralt)
		config.plugins.My_Flow.Messagebox = ConfigSelection(default="MMitte", choices = messagealt)
		config.plugins.My_Flow.Timeshift = ConfigSelection(default="TSUntenRechts", choices = timeshiftalt)
		config.plugins.My_Flow.RadioInfo = ConfigSelection(default="RadioInfoM", choices = radioinfoalt)
		config.plugins.My_Flow.GP41 = ConfigSelection(default="Nothing", choices = gp41)

#######################################################################

		list = []
		list.append(getConfigListEntry(_("-Design-"), ))
		list.append(getConfigListEntry(_("Farbauswahl"), config.plugins.My_Flow.Color))
		list.append(getConfigListEntry(_("Select Farbe"), config.plugins.My_Flow.SelectionBackground))
		list.append(getConfigListEntry(_("Uhr layout"), config.plugins.My_Flow.Clock))
		list.append(getConfigListEntry(_("Volume layout"), config.plugins.My_Flow.Volume))
		list.append(getConfigListEntry(_("Channelselection"), config.plugins.My_Flow.Channel))
		list.append(getConfigListEntry(_("Display für DM9X0"), config.plugins.My_Flow.Display))
		list.append(getConfigListEntry(_("Message Box"), config.plugins.My_Flow.Messagebox))
		list.append(getConfigListEntry(_("-InfoBar-"), ))
		list.append(getConfigListEntry(_("unter Picon"), config.plugins.My_Flow.TunerInfoBar))
		list.append(getConfigListEntry(_("unten links"), config.plugins.My_Flow.LeftInfoBar))
		list.append(getConfigListEntry(_("unten rechts"), config.plugins.My_Flow.RechtsInfoBar))
		list.append(getConfigListEntry(_("Vpninfo Icon"), config.plugins.My_Flow.VPNInfoBar))
		list.append(getConfigListEntry(_("InfoBar With Poster"), config.plugins.My_Flow.PosterInfoBar))
		list.append(getConfigListEntry(_("Wetter oben"), config.plugins.My_Flow.WeatherInfoBar))
		list.append(getConfigListEntry(_("Timeshift"), config.plugins.My_Flow.Timeshift))
		list.append(getConfigListEntry(_("-sonstiges-"), ))
		list.append(getConfigListEntry(_("DVB-Radio Infos"), config.plugins.My_Flow.RadioInfo))
		list.append(getConfigListEntry(_("GP4.1 Screens"), config.plugins.My_Flow.GP41))
		ConfigListScreen.__init__(self, list)


#######################################################################

	def GetPicturePath(self):
		try:
			returnValue = self["config"].getCurrent()[1].value
			path = "/usr/lib/enigma2/python/Plugins/Extensions/My Flow/Images/" + returnValue + ".png"
			return path
		except:
			return "/usr/lib/enigma2/python/Plugins/Extensions/My Flow/Images/prev.png"

	def UpdatePicture(self):
		self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)
		self.onLayoutFinish.append(self.ShowPicture)

	def ShowPicture(self):
		self.PicLoad.setPara([self["preview"].instance.size().width(),self["preview"].instance.size().height(),self.Scale[0],self.Scale[1],0,1,"#002C2C39"])
		self.PicLoad.startDecode(self.GetPicturePath())

	def DecodePicture(self, PicInfo = ""):
		ptr = self.PicLoad.getData()
		self["preview"].instance.setPixmap(ptr)

	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.ShowPicture()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.ShowPicture()

	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.ShowPicture()

	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.ShowPicture()

	def save(self):
		for x in self["config"].list:
			if len(x) > 1:
        			x[1].save()
			else:
       				pass

#######################################################################


		self.skin_lines = []

		try:

			self.appendSkinFile(self.daten + config.plugins.My_Flow.Color.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.Clock.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.Volume.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.Channel.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.Display.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.Messagebox.value + ".xml")
			self.appendSkinFile(self.daten + "InfoBarStart.xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.LeftInfoBar.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.PosterInfoBar.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.WeatherInfoBar.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.RechtsInfoBar.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.VPNInfoBar.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.TunerInfoBar.value + ".xml")
			self.appendSkinFile(self.daten + "InfoBarEnd.xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.Timeshift.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.RadioInfo.value + ".xml")
			self.appendSkinFile(self.daten + config.plugins.My_Flow.GP41.value + ".xml")
			self.appendSkinFile(self.daten + "Main.xml")
			self.appendSkinFile(self.daten + "End.xml")

			xFile = open(self.dateiTMP, "w")
			for xx in self.skin_lines:
				xFile.writelines(xx)
			xFile.close()

			o = open(self.datei,"w")
			for line in open(self.dateiTMP):
				line = line.replace("#21624d", config.plugins.My_Flow.SelectionBackground.value )
				o.write(line)
			o.close()
			system('rm -f ' + self.dateiTMP)

		except:

			self.session.open(MessageBox, _("Error creating Skin!"), MessageBox.TYPE_ERROR)
		configfile.save()
		restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("GUI needs a restart to apply a new skin\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Restart GUI"))

	def restartGUI(self, answer):
		if answer:
			self.session.open(TryQuitMainloop, 3)

	def appendSkinFile(self,appendFileName):
		if path.exists(appendFileName):
			skFile = open(appendFileName, "r")
			file_lines = skFile.readlines()
			skFile.close()
			for x in file_lines:
				self.skin_lines.append(x)
		else:
			print "[My Flow] %s not existing" % appendFileName

	def exit(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].cancel()
		self.close()

#######################################################################

def main(session, **kwargs):
	session.open(MyFlow)

def Plugins(**kwargs):
	return PluginDescriptor(name="My Flow", description=_("Make your Flow"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)
